# Optional private context

A blank profile is sufficient. A host may use an explicitly authorised private folder to store goals/preferences in `profile.json` and practice observations in append-only `practice.jsonl`. Keep that folder outside every installed skill and any shared repository. Do not auto-discover other notes, workplace records or personal history.

Use the bundled [state helper](../scripts/state.py) only when the user asks to initialise, validate, migrate or restore data. It requires an explicit `--data-dir`. It does not send data, call APIs or change host settings. Read the [v2 profile schema](../schemas/profile-v2.schema.json) and [v1 practice schema](../schemas/practice-v1.schema.json) for the interchange contract. Schema versions are independent of package versions. Unknown fields are retained.

Commands: `python3 scripts/state.py init --data-dir /your/private-folder`; `validate`, `migrate`, and `rollback` use the same option. Rollback additionally needs `--backup` pointing to the migration backup. Paths here are placeholders to replace, never defaults to an existing personal location.

Migration from profile v1 to v2 adds an empty preferences object while retaining earlier fields and the complete practice file unchanged. Backups contain private data and belong in the same private folder. Rollback is refused if the current profile has changed since migration; reconcile newer changes rather than discarding them. Future unsupported versions fail without mutation. Installing/updating the shared skill never migrates user data automatically.

A practice record identifies method/package versions, prediction, observation, guardrail and review decision. Actual results may remain pending. Preserve declined, stopped and mixed outcomes. Do not mine history into generic cards without a separate explicit contribution and privacy review.

## Optional situation snapshots

The [situation schema](../schemas/situation-v1.schema.json) supports a task-local record with typed dimension values, evidence/account basis, unknowns, disputed information and corrections. It is a separate optional interchange format; the state helper still manages profile v1/v2 and practice v1 only and does not validate or migrate situation snapshots. You can keep a situation in conversation without a file. Saving needs an explicitly authorised private destination outside shared/discovered skill folders.

Record only useful context. Retain correction provenance without copying unnecessary raw conversations, sensitive personnel details or third-party identifiers. Current task choices do not automatically become permanent preferences. Existing profile/practice schemas and migration behavior are unchanged by package 0.2.0.

## Single-writer safety

Initialisation, migration and rollback use an exclusive `.state-mutation.lock` in the chosen private directory. Another helper mutation fails without waiting or stealing the lock. Migration/rollback recheck profile bytes immediately before replacement and refuse detected intervening edits. Stop external editors, sync writers and other tools first: writers that ignore the lock can still race the final check; this is not a general filesystem transaction or compare-and-swap guarantee. Practice history is never rewritten by migration/rollback.

Normal completion or a handled error removes the lock. An interrupted process can leave it behind; confirm no helper or other writer is running and preserve a copy of the private state before manually removing only the stale lock and retrying. Never remove an active writer's lock. If a late edit is detected during migration, an unused backup/receipt may remain; the current profile is retained. Keep the directory private and outside any skill tree, including copied skills, and any Git checkout.
