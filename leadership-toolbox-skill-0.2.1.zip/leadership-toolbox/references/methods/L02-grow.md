# L02 · GROW coaching

Version: 0.2.1 · Licence: MIT

**Job:** Help someone choose their own next step.

**Use when:** A person wants to explore a goal and has enough knowledge and freedom to choose.

**Avoid/stop when:** Instruction, resources, a formal decision or protection is needed; do not coach someone into accepting overload.

**Prerequisites:** Consent to a coaching conversation and a goal within their influence.

**Estimated time:** 10–25 minutes. This is an editorial planning estimate.

**Participants/preparation:** A leader and the relevant person(s); use one concrete task or episode, relevant evidence and the stated prerequisites. Invite access needs and a way to raise concerns privately. Facilitation is required for group input; qualification remains with the task owner.

## Try it

1. Ask what outcome would be useful.
2. Explore what is happening, including evidence and constraints.
3. Invite several options and their tradeoffs.
4. Ask which next step they choose, what support they need and when to review it.

**Adapt the execution:** State which goals/actions are genuinely open and what you may later evaluate as their manager. Switch to instruction or a resource decision if exploration exposes that need. At review, separate trying the action from its usefulness.

**Words to try:** “What would you choose to try next, and what might get in the way?”

**Immediate output:** A person-owned action and a review agreement, or an explicit decision not to act.

**One outcome signal:** At the agreed review, did the person attempt the chosen action and find it useful for their goal? Agree the definition, baseline (or unknown), observation window and review date before acting.

**Guardrail and stop/switch:** Watch pressure to choose the leader’s preferred answer or an impossible commitment. Switch to instruction or a resource decision when needed.

## Evidence and origin

GROW is a conversation structure (Goal, Reality, Options, Will). General coaching findings do not isolate the effect of this structure in every workplace.

[Public source](https://www.performanceconsultants.com/resources/the-grow-model/). This card’s workplace wording, example and observation guidance are editorial applications, not claims by the source provider. No source article or figure is reproduced.

## Fictional example

An experienced colleague wants to prepare for a new meeting. Explore options and let them choose the rehearsal they will try.

## Counterexample and route change

A manager already decided the answer and uses questions to extract apparent consent; state the directive and its real boundaries instead.

Related alternatives: [Teach–Practice–Check-back (L12)](L12-teach-practice.md), [Capacity tradeoff (L09)](L09-capacity.md). Use a sequence only when one method produces a needed prerequisite; name the owner and transition condition.

## Current provider notice

Performance Consultants' current GROW page and terms assert licensing, reuse and AI-processing restrictions for its original model/materials. This toolbox uses independently authored commentary and does not reproduce its graphics, instruments or templates. This source review records the provider's notice; it does not determine enforceability or provide legal clearance. See the [provider terms](https://www.performanceconsultants.com/terms-and-conditions/) before any proposed source-material reuse.

## Deeper knowledge and evidence

Read the [topic explanation](../knowledge/coaching-development.md) and [method-specific evidence map](../evidence-map.md#l02). Neither the acronym alone nor this short manager-led rendition was isolated; chosen goals and evaluative power matter.
