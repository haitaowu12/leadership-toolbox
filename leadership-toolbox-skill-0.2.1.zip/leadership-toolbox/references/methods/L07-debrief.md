# L07 · Structured debrief

Version: 0.2.1 · Licence: MIT

**Job:** Learn from a completed episode.

**Use when:** There is a finished episode and participants can compare intention with events.

**Avoid/stop when:** It is being used to assign blame, compel disclosure or substitute for an independent investigation.

**Prerequisites:** A bounded episode, enough psychological safety for differing accounts and someone to own a feasible follow-up.

**Estimated time:** 15–30 minutes. This is an editorial planning estimate.

**Participants/preparation:** A leader and the relevant person(s); use one concrete task or episode, relevant evidence and the stated prerequisites. Invite access needs and a way to raise concerns privately. Facilitation is required for group input; qualification remains with the task owner.

## Try it

1. Recall the intended result and what actually happened.
2. Invite differing observations before explanations. Compare accounts with a relevant record or observer where feasible; solitary recollection is self-reflection rather than the full reviewed debrief intervention.
3. Identify what helped, what obstructed and what remains uncertain.
4. Choose one feasible change and its owner.
5. Decide when to check whether it helped.

**Adapt the execution:** Reconstruct what people knew then, what they did, and what became known later. Distinguish skill, coordination and system conditions. Rehearse the selected next response or define a bounded test; link it to the next comparable episode.

**Words to try:** “What actually happened, whose account differs, and what one change will we test?”

**Immediate output:** One learning change, its rationale, owner and next check.

**One outcome signal:** In the next comparable episode, was the change used and did the targeted problem recur? Agree the definition, baseline (or unknown), observation window and review date before acting.

**Guardrail and stop/switch:** Watch selective memory, blame and extra work without resources. Separate formal incident findings from the learning conversation.

## Evidence and origin

Informed by AHRQ debriefs; research on debriefing reports average effects in studied settings, not guaranteed individual outcomes.

[Public source](https://www.ahrq.gov/teamstepps-program/curriculum/team/tools/debrief.html). This card’s workplace wording, example and observation guidance are editorial applications, not claims by the source provider. No source article or figure is reproduced.

## Fictional example

After a workshop, compare the intended decisions with the actual output and choose one change to the next agenda.

## Counterexample and route change

A traumatic event triggers mandatory emotional recounting; operational learning is not psychological treatment.

Related alternatives: [Fishbone causal-hypothesis map (L20)](L20-fishbone.md), [PDSA bounded test (L08)](L08-pdsa.md). Use a sequence only when one method produces a needed prerequisite; name the owner and transition condition.

## Deeper knowledge and evidence

Read the [topic explanation](../knowledge/decisions-learning.md) and [method-specific evidence map](../evidence-map.md#l07). No promised local percentage gain or causal moderator ranking; sparse comparisons and hindsight limit interpretation.
