# L28 · Individual development plan

Version: 0.2.1 · Licence: MIT

**Job:** Coordinate a supported longer-term growth pathway.

**Prerequisites:** The person's aspirations, plausible opportunities, manager support and time/resources that can be genuinely committed.

**Estimated time:** 30–60 minutes for initial preparation/session, not total implementation time. Editorial planning range; adapt to accessibility and complexity.

**Participants/preparation:** Include the legitimate owner and the people whose knowledge or acceptance the card requires. Share the purpose and access options; no disclosure or agreement is assumed.

**Use / avoid.** Use when someone wants growth beyond immediate task delivery and the manager can help secure suitable experiences. Avoid presenting it as a promotion promise, disguised disciplinary plan, or list of courses disconnected from practice.

## Try it

1. Ask the employee about near- and longer-term aspirations.
2. Compare current strengths and demonstrated gaps with capabilities needed for plausible future work.
3. Choose one or two development objectives.
4. Select an experience that makes the capability observable: shadowing, a bounded stretch assignment, guided practice, or a rotation, with training where useful.
5. Agree support, time, resources, and what successful learning would look like.
6. Record the employee's action and the manager's enabling commitment.
7. Review actual work evidence and revise the plan as interests or opportunities change.

**Output / distinction.** A jointly owned development plan with objectives, experiences, support, dates, and demonstration criteria. Teaching addresses a particular skill episode; this coordinates a longer development pathway and access to opportunities.

**Adapt the execution:** Track access to the promised experience separately from learning demonstrated. For stretch work, name a sign that challenge exceeds support and who can reduce scope or give feedback. Delivery success and learning can diverge.

**Words to try:** “Which experience would let you demonstrate this capability, and what support do I need to secure?”

**One outcome signal:** Observe promised access and demonstrated learning separately; missing opportunity is not the person's failure to develop. Agree the definition, baseline (or unknown), observer, observation window and review trigger before action.

**Balancing guardrail and stop/switch:** No promotion promises, disguised disciplinary process, inequitable opportunity access or unpaid stretch work. If a prerequisite fails, prepare the missing evidence or use the appropriate owner/process before committing.

## Example and counterexample (fictional)

An analyst chooses a supervised facilitation assignment and mentor check-ins, with time released from other work.

Counterexample: A development plan lists courses but no opportunity to practise or demonstrate the capability.

## Combinations and next move

Related alternatives: [Teach–Practice–Check-back (L12)](L12-teach-practice.md), [Performance and learning goal design (L16)](L16-goal-design.md). Use a sequence only when one method produces a needed prerequisite; name the owner and transition condition.

**Reuse and evidence:** Prompts, examples, time ranges and observation guidance are this project's editorial adaptation. No provider article, diagram, assessment or worksheet is bundled. The cited source documents the method or a bounded research claim, not the effectiveness of this card in every workplace.

## Design a bounded development assignment

Separate the capability to develop from the work deliverable. Jointly check task difficulty, capacity, access and willingness. Agree the person's actual decision authority, mentoring, recovery limits and checkpoints before starting. Observe skill application in relevant work; completion alone is not proof of learning. Review hidden workload and fair access to opportunities. Do not disguise unsupported critical delivery or unpaid overwork as a stretch assignment. [CCL on on-the-job learning](https://www.ccl.org/articles/leading-effectively-articles/develop-strong-leaders-with-on-the-job-learning/) is practitioner guidance; do not turn a percentage mnemonic into a universal development allocation.

## Supporting provenance

**Primary source.** U.S. Office of Personnel Management, [Career Development](https://www.opm.gov/policy-data-oversight/training-and-development/career-development/). **Claim / limit:** describes employee–supervisor partnership, specific objectives, developmental activities, and continuous feedback; explicitly distinguishes IDPs from performance evaluation. This is practice guidance, not evidence that completing a form creates capability or career advancement.

## Deeper knowledge and evidence

Read the [topic explanation](../knowledge/coaching-development.md) and [method-specific evidence map](../evidence-map.md#l28). No IDP form or fixed stretch proportion is validated; observational challenge findings are not dose prescriptions.
