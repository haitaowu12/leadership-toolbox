# Validation and limits · 0.2.1 draft

## Independent review and manual checks · 20 October 2026

The [independent PR review](evaluations/independent-pr-review-2026-10-20.md) completes the separate substantive review left outstanding on 6 October. It records a repaired dangling-link initialization case, a source-backed clarification of L23's external cue versus controlled response, verification of the frozen comparison record, and 77 passing tests on Python 3.10.22 and 3.12.14. Checks were run locally because hosted Actions minutes were unavailable. The report recommends repository merge while retaining the live-host and human-use pilot gates; it does not approve broad rollout. The final PR record identifies the exact published tree and final checks.

## Robustness audit and matched native comparison

The  separates the frozen 32-reply comparison at ca672dd from subsequent state/installer repairs and their regression tests. It finds selective conversational benefits, a compact-map disadvantage, unknown token/latency/cash costs, and four reproducible software gaps. It does not clear broad rollout or imply that the requested separate Pro review or a live target-tenant test completed. Follow PR 2 for exact-head CI rather than extending historical passes.

## Default inquiry and practical references

The [nine-response check](evaluations/default-inquiry-2026-10-05.md) records native-model behavior for unprompted clarification, correction and stop requests, direct practical explanations, research claims, sufficient context and protection boundaries. Inputs and outputs are preserved with snapshot hashes. Navigation formatting was subsequently checked structurally. This is repository-first work: no new Copilot ZIP or tenant validation is claimed.

Automated checks now also reject practical-guide URL drift and verify that primary-source links and the L05/L27 licence boundaries remain separate from practical guide links. These are structural assertions, not proof of citation correctness or assistant behavior. Consult this change's exact-head CI for final counts and results.

## Historical 0.2.0 completion checks

The completion revision closes full-text reading gaps for E23, E43, E60 and E61. E24 remains abstract-only for the article; the related publisher procedure record does not substitute for its methods/results. Research access is now 24 full-text relevant-section inspections and one abstract-only record. Nine book/chapter excerpts are partially inspected; one book is metadata-only. Access counts do not rank quality.

Runtime guidance now requires a distinguishing observation before presuming a blockage or deficit. Trial plans separate cue/opportunity, response and outcome; name a proposed observer and window; retain unknown baselines; and treat no opportunity as not tested. This is editorial guidance whose observed model behavior is evaluated separately.

Packaging now includes a source ZIP, single-skill upload ZIP and checksums. Twelve added tests cover archive layout/bytes, deterministic repeat builds in one runtime, metadata, unsafe paths, incomplete/environment-file rejection, a real clean extracted-archive CLI install/update/restore with separate-state preservation, and repair of damaged destinations. An independent static review found missing-dependency and damaged-destination recovery gaps; those findings drove the final three regression tests. CI targets Python 3.10 and 3.12 with read-only permissions. At [f8dd69e9](https://github.com/haitaowu12/leadership-toolbox/commit/f8dd69e996d0db47ae448c7ff8bfbee799c67cd0), the [direct-head push run](https://github.com/haitaowu12/leadership-toolbox/actions/runs/37375090624) passed all 57 tests on Python 3.10.21 and 3.12.14, validated 100 reviewed files/32 methods, built both archives and uploaded the artifact. Inspected logs confirm the exact head and read-only contents/metadata permissions. A downloaded skill ZIP's 70 file hashes also matched the Git tree. Later documentation/report commits require their own checks; no earlier pass is silently extended.

The [matched comparison protocol](evaluations/completion-protocol.json) fixes four fictional situations and concise/probing controls before generation. Fresh no-skill and skill-reading contexts are compared by reviewers independent of generation. The [completed comparison](evaluations/completion-comparison-2026-10-05.md) preserves 16 responses and two independent model reviews. Both arms handled the main safety/no-intervention choices well; reviewers identified narrow follow-through and outcome-observation advantages in two concise skill responses. No human-benefit or general superiority claim follows.

The [cloud upload route](installation.md#cloud-upload-without-a-local-install) follows current official Claude web documentation. ZIP layout, metadata and resource checks do not establish account upload or live host activation. Manual native model loading of repository references is also different from automatic host discovery.

## Knowledge-library refinement

The later knowledge-library revision adds 25 research records, 10 book/preview records and 29 retained procedure/operational references. Four explanatory topics feed the interview, routing, all 32 cards and 16 refined outcome contracts. Full text was inspected for relevant article methods/findings/limits where obtainable; book and abstract limits remain explicit. A targeted independent source check verified selected consequential claims and corrected the coaching sample description, book-access labels and the model-dependent interpretation of publication-bias adjustment. This was not an exhaustive literature search or independent replication.

The new source-integrity tests check IDs, complete method coverage, cross-links, source scope/rights fields and rejection of metadata-only empirical support. They do not establish source truth, copyright clearance or intervention effectiveness. Refer to the current PR's exact-head CI; earlier reported passes below apply only to their stated revisions. Previous conversational evaluations do not validate the new knowledge instructions.

At [637a283](https://github.com/haitaowu12/leadership-toolbox/commit/637a283b9a64c9643ea859b8488497e339d7300c), the [direct-head run](https://github.com/haitaowu12/leadership-toolbox/actions/runs/37368929434) passed 95 reviewed files, 32 methods, all 45 tests and archive construction. The later preserved evaluation report adds one public file; consult its exact-head checks rather than extending this pass automatically.

A [five-case/six-response check](evaluations/knowledge-routing-2026-10-05.md) at frozen 637a283 preserved concise mechanism-sensitive answers and an authority correction, but every output cited repository material instead of an underlying external source. That historical revision required an original public source link for every explanation. Version 0.2.1 supersedes that rule: practical explanations use the method wiki, while empirical claims and evidence requests retain primary-source citation and scope limits. The concrete proposed observation checkpoint remains relevant where practical. This is a narrow correction; editing an instruction alone does not demonstrate improved behavior. The complete report retains leading-prompt, single-context, measurement and self-assessment limitations.

## Current expansion

This version expands the catalog to 32 methods, adds adaptive quick/deep interviewing, eight mixed-type context dimensions, explicit matching profiles and metric contracts, and removes the fixed 14-method implementation limit. It also moves installer staging/backups outside the immediate discovery root and adds regression coverage.

At [9f49b19](https://github.com/haitaowu12/leadership-toolbox/commit/9f49b19f7cf2b4b0bda7505e43e7b52a5a3d867d), GitHub Actions passed structural validation for 81 reviewed files and all 32 methods, all 31 standard-library tests, and construction of the 0.2.0 archive. The [push run](https://github.com/haitaowu12/leadership-toolbox/actions/runs/37352208205) tests that head directly; the [PR run](https://github.com/haitaowu12/leadership-toolbox/actions/runs/37352208427) tests its synthetic merge with the base. Inspected PR logs show Ubuntu 24.04.5, CPython 3.12.14 and read-only contents/metadata permissions. Official actions are pinned and credentials are not persisted; no release/deploy step runs.

These checks cover package/data behavior, dynamic catalog/metric contracts, paths, allowlists, archive integrity and installer failure/restore behavior. They do not execute a conversational model or fully validate every JSON Schema instance. Later source changes require fresh checks; consult the current draft PR's exact-head results rather than treating this recorded run as a pass for arbitrary future revisions. No user-computer action or assistant-host activation is claimed for this expansion.

## Fresh conversational checks

A [three-turn correction dialogue](evaluations/forward-dialogue-2026-10-05.md) was actually executed against frozen 9f49b19 in a fresh model context, with full inputs/outputs and read provenance retained. It changed the next move after authority, prior-warning and voice facts were corrected and respected a request to stop questioning. The report also records leading-question and verbosity caveats. This is a narrow model execution, not evidence of human effectiveness or a calibrated matching score.

A separate [six-case expansion review](evaluations/forward-expansion-2026-10-05.md) retains seven further generated responses against the same frozen revision, its read manifest and self-assessment. It found no unsafe recommendation in that limited sample, while identifying schema consistency gaps, stale PR metadata, a source-register omission and overly long quick answers. The follow-up revision tightens the optional schema, adds structural regression guards/label consistency checks, updates the notices/PR summary and instructs quick mode to compress its answer. These schema checks inspect declared constraints; they are not a complete JSON Schema validation engine. A changed instruction is not itself proof of improved behavior.

## Historical 0.1.0 evidence

The earlier package snapshot at [c11e9f8](https://github.com/haitaowu12/leadership-toolbox/commit/c11e9f80154542ba3bdcdccdd6b86cf801f984ee) recorded 56 reviewed files, 14 methods and 14 passing functional tests in an isolated Mac filesystem using Python 3.13.5. Those results do not validate the later expansion.

The [eight-case report](evaluations/forward-2026-10-05.md) and [seven-case extension](evaluations/forward-extension-2026-10-05.md) retain 15 model-generated prompt/response executions. The evaluator also assessed its outputs, so these are not blinded independent scoring or human research. [Challenge coverage](evaluations/challenge-coverage.md) records gaps. These reports are historical artifacts; exact generating model/settings and pre-generation package hashes were not retained in a reproducible manifest. Their presence in c11e9f8 identifies the published snapshot, not proof of the exact model input bytes. Do not imply stronger provenance.

## Sources and rights

The [original-source audit](source-audit-2026-10-05.md) attempted all 34 unique URLs in the original source/framework register: 28 directly readable, 6 reader obstacles with official/institutional corroboration, and no confirmed dead links. It is explicit about abstract/index-only checks and asset/rights limits. The expansion sources were reviewed separately when the new cards were prepared; this audit does not claim an exhaustive check of every URL anywhere in the repository. Public primary-source review supports method descriptions, source types and reuse cautions. The source register identifies bounded claims and editorial transfers. External URLs can change; structural local-link checks do not certify every current page, asset or licence. No provider assessment instrument, article, image or proprietary template is bundled. Source review is not comprehensive legal clearance.

## Reproduce

From repository root: `python3 scripts/validate.py`, `python3 -m unittest discover -s tests -v`, `python3 scripts/build_release.py`. Tests use only the standard library. The source/privacy scan is heuristic plus an explicit allowlist; it cannot identify every possible confidential sentence. A later fix does not remove earlier Git history.

A structural pass does not establish method effectiveness, correct matching in all situations, universal host compatibility or safe deployment in regulated work. Workplace outcomes, live discovery across hosts, accessibility of actual platforms and the new interview's empirical usefulness remain unvalidated. Consult the reviewed PR and current branch for merge status; no site/service is deployed or GitHub Release implied.

## Correctable situation models, 0.2.1 draft

The [visual-modelling evaluation](evaluations/visual-modelling-2026-10-06.md) retains four actual responses with source hashes: initial understanding, authority correction plus problem/options, no diagram, and contested decision rights. It distinguishes text-model behavior and four new static consistency tests from untested Mermaid/Copilot rendering, automatic discovery and human outcomes. The capability adds no method IDs, renderer or dependencies. Use the exact-head CI for the current draft rather than extending an earlier test pass.
