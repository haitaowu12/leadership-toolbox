# Changelog

## 0.2.1 review follow-up · 2026-10-20

- Complete the separate substantive PR review, verify the frozen comparison record, and run the required Python 3.10/3.12 checks locally. Retain host-activation and human-use limits separately from repository merge readiness.
- Reject a dangling profile/history symlink before optional-state initialisation creates either file; preserve the existing link and leave no partial profile or helper lock.
- Clarify L23's cue/response distinction in the method card and catalog: an external cue is valid when the chosen response is feasible and within the person's authority and control. No cue still means not tested.

## 0.2.1 draft · inquiry, practical references and correctable models · 2026-10-05

- Audit the frozen candidate against matched no-toolbox conversations; retain selective benefits, verbosity/loading costs and explicit rollout limits.
- Repair optional-state concurrent helper mutations and intervening-edit detection, nested copied-skill privacy paths, non-object profile errors, and incoming installer entrypoint validation. Add non-destructive regression tests and document the cooperative-lock boundary.

- Ask decision-relevant questions by default for underspecified leadership situations, wait before prescribing, and preserve direct lookup, sufficient-context, explicit quick/skip and urgent-protection routes.
- Use the existing plain-language method pages as the practical wiki front door; retain primary citations for empirical claims, research requests, attribution and healthcare/regulatory transfer limits.
- Keep normal recommendations compact; reserve candidate matrices and measurement contracts for decisions/trials that need them. Add task-based navigation, descriptive method links and scannable steps before deeper provenance.
- Add exact public guide links and routing/citation regression cases. Keep new conversational checks separate from actual tenant behavior; no new Copilot package or tenant validation is claimed.

- Add optional visual situation modelling with context/authority, process/dependency, problem-hypothesis and solution-option views; stable IDs, evidence statuses, unknown/conflicting accounts, and correction propagation to narrative and method choice. Include portable text templates and original fictional examples; Mermaid remains optional and host rendering is not assumed.

## 0.2.0 · completion · 2026-10-05

- Add a cloud-upload single-skill ZIP, deterministic archive metadata, checksums, downloadable CI artifacts and exact non-Codex use instructions.
- Reject incomplete incoming packages, unsafe paths and environment files, and repair damaged destinations while retaining their bytes; exercise clean archive CLI install/update/restore on Python 3.10 and 3.12.
- Close four priority full-text access gaps while retaining E24's article-level limit and all causal/transfer boundaries.
- Turn knowledge into discriminating observations; remove presumed blockages and specify opportunity-aware, proportionate observation.
- Add a predeclared matched no-skill comparison with concise/probing controls; see validation for executed results and limitations.

## 0.2.0 draft · knowledge-library refinement · 2026-10-05

- Organized sources into stable research, book/chapter and procedure-provenance records, with truthful inspection scopes and claim/reuse limits.
- Added four reusable knowledge chapters, 25 research records and 10 book/preview records. Sources include null/adverse results, corrected figures, limited populations and model-dependent publication-bias estimates.
- Mapped all 32 methods to sources and explicit unanswered questions; revised execution guidance across the catalog and 16 observation contracts.
- Connected the adaptive interview and method selection to mechanisms/rival explanations; retained quick-mode stopping rules and no global quality scores.
- Fresh knowledge-routing checks exposed repository-only citations; clarified the requirement to link the underlying external source and make proposed observation checkpoints concrete.
- Added source integrity and mapping regression tests; existing human-effectiveness and model-execution reports remain historical, not validation of this revision.


## 0.2.0 — 2026-10-05 (draft)

- Expand from 14 to 32 distinct methods, with practical steps, source boundaries, prompts, examples, counterexamples and output/outcome/guardrail contracts.
- Add adaptive quick/deep “grill me” interviewing, user corrections, eight mixed-type dimensions and transparent prerequisite-first matching; no summed global scores or success probabilities.
- Add structured profiles for every method, sensemaking/action distinctions, sequences and a private optional situation schema.
- Strengthen no-agreement negotiation, supported development assignments and proxy cautions.
- Replace source-specific privacy markers with generic checks, remove hardcoded catalog counts, move install staging/backups outside discovery and add 20 regression tests.
- Record fresh dialogue and six-case model reviews, improve quick-mode brevity and schema consistency, and audit the original 34 source URLs with access limits.
- Add minimal pinned read-only GitHub Actions; update source installation and historical evaluation provenance. Consult validation docs for actual execution status.

## 0.1.0 — 2026-10-05 (draft)

- Create a standalone installable leadership skill with fourteen stable method IDs and six generic situation guides.
- Add practical routing, locally defined outcome/guardrail observations, public-source notes and per-file licence boundaries.
- Add separate optional user data, versioned schemas, safe migration/rollback, clean archives and install checks.
- Record 14 functional checks and 15 fictional model executions with their historical verification limits; no human field outcomes claimed.
